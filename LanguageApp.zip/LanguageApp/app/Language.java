package com.example.languageapp;
public class Language {
}
