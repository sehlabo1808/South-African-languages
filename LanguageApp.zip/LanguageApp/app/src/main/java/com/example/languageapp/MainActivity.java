package com.example.languageapp;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SearchView;

import com.example.languageapp.businesslogic.Language;
import com.example.languageapp.businesslogic.Province;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private List<Language> languageList;
    private ArrayAdapter<Language> adapter;
    private ListView listView;
    private Button addButton;
    private SearchView searchView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // Initialize the language list
        languageList = new ArrayList<>();
        populateLanguageList();

        // Initialize the adapter
        adapter = new LanguageAdapter(this, languageList);

        // Set up the ListView
        listView = findViewById(R.id.listView);
        listView.setAdapter(adapter);

        // Initialize the "Add Language" button
        addButton = findViewById(R.id.btnAddLanguage);

        // Set the OnClickListener
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle the button click event
                showAddLanguageDialog();
            }
        });

        // Initialize the SearchView
        searchView = findViewById(R.id.searchView);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                filterLanguageList(newText);
                return true;
            }
        });
        // Set the OnItemClickListener for the ListView
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Language selectedLanguage = (Language) parent.getItemAtPosition(position);
                showLanguageDetails(selectedLanguage);
            }
        });
    }
    private void addLanguage(String languageName, String provinceName) {
        Province province = getOrCreateProvince(provinceName);
        Language newLanguage = new Language(languageName, province);
        languageList.add(newLanguage);
        adapter.notifyDataSetChanged();
    }
    private Province getOrCreateProvince(String provinceName) {
        // Check if the province already exists in the languageList
        for (Language language : languageList) {
            if (language.getProvince().getName().equalsIgnoreCase(provinceName)) {
                return language.getProvince();
            }
        }

        // If the province doesn't exist, create a new one
        Province newProvince = new Province(provinceName);
        languageList.add(new Language("", newProvince)); // Empty language for reference
        return newProvince;
    }

    private void showLanguageProvinces(Language selectedLanguage) {
        Province languageProvince = selectedLanguage.getProvince();

        List<Province> associatedProvinces = new ArrayList<>();
        for (Language language : languageList) {
            if (language.getProvince().equals(languageProvince)) {
                associatedProvinces.add(language.getProvince());
            }
        }

        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);
        dialogBuilder.setTitle("Provinces for " + selectedLanguage.getName());

        StringBuilder messageBuilder = new StringBuilder();
        for (Province province : associatedProvinces) {
            messageBuilder.append(province.getName()).append("\n");
        }

        dialogBuilder.setMessage(messageBuilder.toString());

        dialogBuilder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        dialogBuilder.create().show();
    }

    private void showLanguageDetails(Language language) {
        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);
        dialogBuilder.setTitle("Language Details");

        // Create the dialog message
        String message = "Language: " + language.getName() + "\n"
                + "Province: " + language.getProvince().getName();
        dialogBuilder.setMessage(message);

        // Set up the positive button
        dialogBuilder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // Close the dialog
                dialog.dismiss();
            }
        });

        // Show the dialog
        dialogBuilder.create().show();
    }

    private void populateLanguageList() {
        // Create some initial languages and provinces
        Province province1 = new Province("Eastern Cape");
        Province province2 = new Province("Western Cape");

        Language language1 = new Language("Xhosa", province1);
        Language language2 = new Language("Afrikaans", province2);
        Language language3 = new Language("Sotho", province1);

        // Add languages to the list
        languageList.add(language1);
        languageList.add(language2);
        languageList.add(language3);
    }
    private void filterLanguageList(String query) {
        List<Language> filteredList = new ArrayList<>();

        for (Language language : languageList) {
            if (language.getName().toLowerCase().contains(query.toLowerCase())) {
                filteredList.add(language);
            }
        }
        adapter.clear();
        adapter.addAll(filteredList);
        adapter.notifyDataSetChanged();
    }

    private void showAddLanguageDialog() {
        // Create and configure the dialog builder
        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);
        dialogBuilder.setTitle("Add Language");

        // Create the layout inflater
        LayoutInflater inflater = LayoutInflater.from(this);
        View dialogView = inflater.inflate(R.layout.dialog_add_language, null);
        dialogBuilder.setView(dialogView);

        // Get the dialog views
        @SuppressLint({"MissingInflatedId", "LocalSuppress"})
        EditText languageEditText = dialogView.findViewById(R.id.etLanguage);
        @SuppressLint({"MissingInflatedId", "LocalSuppress"})
        EditText provinceEditText = dialogView.findViewById(R.id.etProvince);

        // Set up the positive button
        dialogBuilder.setPositiveButton("Add", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // Retrieve the entered language and province
                String language = languageEditText.getText().toString();
                String province = provinceEditText.getText().toString();

                // Create a new Language object
                Language newLanguage = new Language(language, new Province(province));

                // Add the new Language object to the languageList
                languageList.add(newLanguage);

                // Notify the adapter about the data change
                adapter.notifyDataSetChanged();

                // Close the dialog
                dialog.dismiss();
            }
        });

        // Set up the negative button
        dialogBuilder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // Close the dialog
                dialog.dismiss();
            }
        });

        // Show the dialog
        dialogBuilder.create().show();
    }

}