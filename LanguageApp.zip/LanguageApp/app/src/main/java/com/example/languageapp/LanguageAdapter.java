package com.example.languageapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.languageapp.businesslogic.Language;

import java.util.List;

public class LanguageAdapter extends ArrayAdapter<Language> {
    private LayoutInflater inflater;

    public LanguageAdapter(Context context, List<Language> languages) {
        super(context, 0, languages);
        inflater = LayoutInflater.from(context);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View itemView = convertView;
        if (itemView == null) {
            itemView = inflater.inflate(R.layout.list_item, parent, false);
        }

        Language language = getItem(position);

        TextView languageTextView = itemView.findViewById(R.id.tvLanguage);
        TextView provinceTextView = itemView.findViewById(R.id.tvProvince);

        languageTextView.setText(language.getName());
        provinceTextView.setText(language.getProvince().getName());

        return itemView;
    }
}
