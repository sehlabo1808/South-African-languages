package com.example.languageapp.businesslogic;

// Province.java
import com.example.languageapp.businesslogic.Language;

import java.util.ArrayList;
import java.util.List;

public class Province {
    private String name;
    private List<Language> languages;

    public Province(String name) {
        this.name = name;
        this.languages = new ArrayList<>();
    }

    public String getName() {
        return name;
    }

    public List<Language> getLanguages() {
        return languages;
    }

    public void addLanguage(Language language) {
        languages.add(language);
    }
}
