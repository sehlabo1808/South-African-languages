package com.example.languageapp.businesslogic;

// Language.java
public class Language {
    private String name;
    private Province province;

    public Language(String name, Province province) {
        this.name = name;
        this.province = province;
    }

    public String getName() {
        return name;
    }

    public Province getProvince() {
        return province;
    }
}

